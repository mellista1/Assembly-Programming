<!-- 
POR FAVOR LEER!

Antes de consultar, por favor buscar en el Discord de la materia si no se respondió una pregunta similar. 

Si la pregunta no tiene SPOILERS de resolución, enviarla al servidor de Discord donde recibirán respuesta más rápido.
-->
# Consulta de enunciado
## Trabajo práctico y ejercicio
<!-- Indicar el trabajo práctico y número de ejercicio a consultar. -->
**Trabajo práctico:**

**Ejecicio:**

## Consulta
<!-- Hacer la consulta de enunciado. -->
<!-- Si están preguntando por este medio y no por el discord público debería ser porque la pregunta spoilea parte de la resolución o quieren discutir una posible resolución. De no ser el caso preguntar en el Discord, donde recibirán respuesta más rápido. -->

/label ~"type::consulta enunciado"