#include "ej2.h"


void YUYV_to_RGBA_c( int8_t *X, uint8_t *Y, uint32_t width, 
                            uint32_t height){
    
}
