#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <assert.h>

#include "ej2.h"

int main (void){
    /* Acá pueden realizar sus propias pruebas */
    return 0;
}


